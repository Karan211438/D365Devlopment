const express = require('express');
const axios = require('axios');
const EntityMetadata = require('./CreateEntityMetdata');
const bodyParser = require('body-parser');
const CreateEntityMetdata = require('./CreateEntityMetdata');
const UpdateEntityMetdata = require('./UpdateEntityMetdata');
const createAttribute = require('./CreateAttribute');
const CreateViews= require('./Views/CreateViews');
const UpdateView = require('./Views/UpdateView');
const CreateForm = require('./Forms/CreateForms');
const UpdateForm = require('./Forms/UpdateForm');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

const fetchEntityMetadata = async (tokenData) => {
    const url = `${process.env.YOUR_ORG}/EntityDefinitions`; // Ensure resource is set in .env
    const selectFields = 'MetadataId,LogicalName,DisplayName';

    try {
        const response = await axios.get(url, {
            params: {
                $select: selectFields
            },
            headers: {
                'Authorization': `Bearer ${tokenData}`, // OAuth 2.0 token
                'OData-MaxVersion': '4.0',
                'OData-Version': '4.0',
                'Accept': 'application/json'
            }
        });

        return response.data;
    } catch (error) {
        console.error('Error fetching entity metadata:', error.response ? error.response.data : error.message);
        throw error;
    }
};

app.use(bodyParser.json());

// Log environment variables for debugging
console.log('Tenant ID:', process.env.TENANT_ID);
console.log('Client ID:', process.env.CLIENT_ID);
const url = `${process.env.YOUR_RESOURCE}/EntityDefinitions`;
console.log('Fetching from URL:', url);

// app.post('/api/getcrmtoken', async (req, res) => {
//     const { TENANT_ID, CLIENT_ID, CLIENT_SECRET, YOUR_RESOURCE } = process.env;

//     if (!TENANT_ID || !CLIENT_ID || !CLIENT_SECRET) {
//         return res.status(400).json({ error: 'Missing required environment variables.' });
//     }

//     const params = new URLSearchParams();
//     params.append('grant_type', 'client_credentials');
//     params.append('client_id', CLIENT_ID);
//     params.append('client_secret', CLIENT_SECRET);
//     params.append('resource', YOUR_RESOURCE);

//     try {
//         const response = await axios.post(`https://login.microsoftonline.com/${TENANT_ID}/oauth2/token`, params);
//         res.json(response.data);
//     } catch (error) {
//         console.error(error);
//         res.status(500).json({ error: 'An error occurred while fetching the token.' });
//     }
// });
app.post('/api/getattributes', async (req, res) => {
    const url = process.env.DYNAMICS_API;
    const bearerToken = process.env.BEARER_TOKEN;
     const entityLogicalName = req.body.LogicalName;
     if (!entityLogicalName) {
        return res.status(400).json({
            message: 'LogicalName is required in the request body'
        });
    }
    const apiUrl = `${url}EntityDefinitions(LogicalName='${entityLogicalName}')/Attributes`;
    console.log(apiUrl);
    try {
        // Make the GET request to the Dynamics 365 API
        const response = await axios.get(apiUrl, {
            headers: {
                'Authorization': `Bearer ${bearerToken}`, // Include the bearer token
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        });

        // Send the response data back to the client
        res.status(200).json({
            message: 'Attributes retrieved successfully',
            data: response.data
        });
    } catch (error) {
        console.error('Error retrieving attributes:', {
            message: error.message,
            response: error.response ? error.response.data : null
        });

        res.status(error.response ? error.response.status : 500).json({
            message: 'Error retrieving attributes',
            error: error.response ? error.response.data : error.message
        });
    }
});
app.post('/api/getallsystemviews', async (req, res) => {
    const url = process.env.DYNAMICS_API;
    const bearerToken = process.env.BEARER_TOKEN;
     const entityLogicalName = req.body.LogicalName;
     if (!entityLogicalName) {
        return res.status(400).json({
            message: 'LogicalName is required in the request body'
        });
    }
    const apiUrl = `${url}savedqueries?$filter=returnedtypecode eq '${entityLogicalName}'`;
    //https://ogre-dev.crm11.dynamics.com/api/data/v9.0/savedqueries?$filter=returnedtypecode eq 'account'
    try {
        // Make the GET request to the Dynamics 365 API
        const response = await axios.get(apiUrl, {
            headers: {
                'Authorization': `Bearer ${bearerToken}`, // Include the bearer token
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        });

        // Send the response data back to the client
        res.status(200).json({
            message: 'views retrieved successfully',
            data: response.data
        });
    } catch (error) {
        console.error('Error retrieving views:', {
            message: error.message,
            response: error.response ? error.response.data : null
        });

        res.status(error.response ? error.response.status : 500).json({
            message: 'Error retrieving views',
            error: error.response ? error.response.data : error.message
        });
    }
});
app.post('/api/getallforms', async (req, res) => {
    const url = process.env.DYNAMICS_API;
    const bearerToken = process.env.BEARER_TOKEN;
    const entityLogicalName = req.body.LogicalName;
    if (!entityLogicalName) {
        return res.status(400).json({
            message: 'LogicalName is required in the request body'
        });
    }
    const apiUrl = `${url}systemforms?$filter=objecttypecode eq '${entityLogicalName}'`;
    console.log(apiUrl);
    try {
        // Make the GET request to the Dynamics 365 API
        const response = await axios.get(apiUrl, {
            headers: {
                'Authorization': `Bearer ${bearerToken}`, // Include the bearer token
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        });

        // Send the response data back to the client
        res.status(200).json({
            message: 'forms retrieved successfully',
            data: response.data
        });
    } catch (error) {
        console.error('Error occured while retrieving  forms:', {
            message: error.message,
            response: error.response ? error.response.data : null
        });

        res.status(error.response ? error.response.status : 500).json({
            message: 'Error occured while retrieving forms',
            error: error.response ? error.response.data : error.message
        });
    }
    
});
app.post('/api/createEntityNew', async (req, res) => {
    const url = process.env.DYNAMICS_API;
    const bearerToken = process.env.BEARER_TOKEN;

    // Entity data from request body
   // const entityData = req.body;
    const entityData = new CreateEntityMetdata(req.body);

    console.log(JSON.stringify(entityData, null, 2))
   // console.log(entityData.Attributes.)

    try {
        const response = await axios.post(url+"EntityDefinitions", entityData, {
            headers: {
                'Authorization': `Bearer ${bearerToken}`,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        });

        // Successful creation response
        res.status(201).json({
            message: 'Entity created successfully',
           // data: response.data
        });
    } catch (error) {
        console.error('Error creating entity:', {
            message: error.message,
            response: error.response ? error.response.data : null,
            config: error.config,  // Log the request configuration for context
            requestData: entityData // Log the mapped entity data
        });

        res.status(error.response ? error.response.status : 500).json({
            message: 'Error creating entity',
            error: error.response ? error.response.data : error.message
        });
    }
});
app.post('/api/createAttributes', async (req, res) => {
    const url = process.env.DYNAMICS_API;
    const bearerToken = process.env.BEARER_TOKEN;

    // Entity data from request body
    //const entityData = req.body;
    const attributedata = new createAttribute(req.body);
    console.log(JSON.stringify(attributedata, null, 2))
    console.log(`${url}EntityDefinitions(LogicalName='${req.body.EntityLogicalName}')`+"/Attributes");

    // try {
    //     const response = await axios.put(`${url}EntityDefinitions(LogicalName='${req.body.EntityLogicalName}')`+"/Attributes", attributedata, {

          
    //         headers: {
    //             'Authorization': `Bearer ${bearerToken}`,
    //             'Content-Type': 'application/json',
    //             'Accept': 'application/json'
    //         }
    //     });
    //     // Successful creation response
    //     res.status(201).json({
    //         message: 'Attribute Created successfully',
    //        // data: response.data
    //     });
    // } catch (error) {
    //     console.error('Error  in creating Attribute  entity:', {
    //         message: error.message,
    //         response: error.response ? error.response.data : null,
    //         config: error.config,  // Log the request configuration for context
    //         requestData: entityData // Log the mapped entity data
    //     });

    //     res.status(error.response ? error.response.status : 500).json({
    //         message: 'Error in updating entity ',
    //         error: error.response ? error.response.data : error.message
    //     });
   // }//
});
app.post('/api/createforms', async (req, res) => {
    const url = process.env.DYNAMICS_API;
    const bearerToken = process.env.BEARER_TOKEN;

    const formdata = new CreateForm(req.body);
    console.log(JSON.stringify(formdata, null, 2))
    console.log(`${url}`+"systemforms");

    try {
        const response = await axios.post(`${url}`+"systemforms", {

          
            headers: {
                'Authorization': `Bearer ${bearerToken}`,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        });
        // Successful creation response
        res.status(201).json({
            message:  'form Created successfully',
           // data: response.data
        });
    } catch (error) {
        console.error('Error  in creating  form:', {
            message: error.message,
            response: error.response ? error.response.data : null,
            config: error.config,  // Log the request configuration for context
            requestData: formdata // Log the mapped entity data
        });

        res.status(error.response ? error.response.status : 500).json({
            message: 'Error in creating a form  ',
            error: error.response ? error.response.data : error.message
        });
   }//
});
app.post('/api/updateform', async (req, res) => {
    const url = process.env.DYNAMICS_API;
    const bearerToken = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsIng1dCI6Ik1jN2wzSXo5M2c3dXdnTmVFbW13X1dZR1BrbyIsImtpZCI6Ik1jN2wzSXo5M2c3dXdnTmVFbW13X1dZR1BrbyJ9.eyJhdWQiOiJodHRwczovL29ncmUtZGV2LmNybTExLmR5bmFtaWNzLmNvbSIsImlzcyI6Imh0dHBzOi8vc3RzLndpbmRvd3MubmV0LzUyZDQ2NWJhLWI3YTMtNDM5NS04OTU3LTQ5OWQ3N2YyMDQ3Ny8iLCJpYXQiOjE3Mjc5NjgzMjMsIm5iZiI6MTcyNzk2ODMyMywiZXhwIjoxNzI3OTcyMjIzLCJhaW8iOiJrMkJnWUNqL2wvYmtvL05QN29sSFBhS2E5Lzh3QUFBPSIsImFwcGlkIjoiYmM2Njc2ZDYtMTM4Ny00ZGM0LWJlODktYmExM2IwOGNlYjRlIiwiYXBwaWRhY3IiOiIxIiwiaWRwIjoiaHR0cHM6Ly9zdHMud2luZG93cy5uZXQvNTJkNDY1YmEtYjdhMy00Mzk1LTg5NTctNDk5ZDc3ZjIwNDc3LyIsImlkdHlwIjoiYXBwIiwib2lkIjoiNjg0MWE4OWEtMDUxMy00NWZmLTgwYWYtNjhlZTMyNTNjNjhmIiwicmgiOiIwLkFUQUF1bVhVVXFPM2xVT0pWMG1kZF9JRWR3Y0FBQUFBQUFBQXdBQUFBQUFBQUFBd0FBQS4iLCJzdWIiOiI2ODQxYTg5YS0wNTEzLTQ1ZmYtODBhZi02OGVlMzI1M2M2OGYiLCJ0ZW5hbnRfcmVnaW9uX3Njb3BlIjoiRVUiLCJ0aWQiOiI1MmQ0NjViYS1iN2EzLTQzOTUtODk1Ny00OTlkNzdmMjA0NzciLCJ1dGkiOiJTeHpsVExYR1dFS291VXI2SDZ3YUFBIiwidmVyIjoiMS4wIiwieG1zX2lkcmVsIjoiNyAxNiJ9.l8XuIQ4ls1QW4z0_5XZf9MdHZtJtHnfYvnh6rb7N_uXrAsQXpZBbLYJNqM4bF7X8IIecjhFxmHhbpMNCowGQoFEX7XJ8S9bv5POL3-xB7bVMjcCR-Cxs1m_yKHD4XvE-thzN2jHgf7GQkAEKaIu9y2ImDNgIFl11E99pryzBqw8ZRfQI_mYCHGrzRyK8gPB7MPqtyQGPSh3SJHfy8d3Sy0eb8ESavgzk2QURngo-HjpKl2RGjKwNtQFsdON9be2rHG3XW1ikkBoIkfLaKQz-5fgXflJWvP6t9J6nvDJL23D_469SRigP9-zy40tu-TWRWbhJSIYSXDFLuShZXbnHFA";
    const formId = "869b-3856-408d-bc6c-7b40119e6362";
    const formdata = new UpdateForm(req.body);
    console.log(JSON.stringify(formdata, null, 2))
    console.log(`${url}`+"systemforms");

    try {
        const response = await axios.patch(`${url}systemforms(${formId})`, {

          
            headers: {
                'Authorization': `Bearer ${bearerToken}`,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        });
        // Successful creation response
        res.status(201).json({
            message:  'form updated successfully',
           // data: response.data
        });
    } catch (error) {
        console.error('Error  in updating form:', {
            message: error.message,
            response: error.response ? error.response.data : null,
            config: error.config,  // Log the request configuration for context
            requestData: formdata // Log the mapped entity data
        });

        res.status(error.response ? error.response.status : 500).json({
            message: 'Error in updating a form  ',
            error: error.response ? error.response.data : error.message
        });
   }//
});
app.post('/api/createviews', async (req, res) => {
    const url = process.env.DYNAMICS_API;
     const bearerToken = process.env.BEARER_TOKEN;
    //const bearerToken = req.headers['authorization']?.split(' ')[1];
    console.log(bearerToken);
    const viewsdata = new CreateViews(req.body);
    console.log(JSON.stringify(viewsdata, null, 2))
    console.log(`${url}`+"savedqueries");
    try {
        const response = await axios.patch(`${url}`+"savedqueries", {

          
            headers: {
                'Authorization': `bearer ${bearerToken}`,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        });
        // Successful creation response
        res.status(201).json({
            message: 'views created successfully',
           // data: response.data
        });
    } catch (error) {
        console.error('Error  in creating views for an entity :', {
            message: error.message,
            response: error.response ? error.response.data : null,
            config: error.config,  // Log the request configuration for context
            requestData: viewsdata // Log the mapped entity data
        });

        res.status(error.response ? error.response.status : 500).json({
            message: 'Error in creating a views for  entity ',
            error: error.response ? error.response.data : error.message
        });
   }//
});
app.post('/api/updateviews', async (req, res) => {
     const url = process.env.DYNAMICS_API;
     const bearerToken = process.env.BEARER_TOKEN;
     const savedQueryId = req.body.viewid
     console.log(bearerToken);
    const viewsdata = new UpdateView(req.body);
    console.log(JSON.stringify(viewsdata, null, 2))
    try {
        const response = await axios.patch(`${url}savedqueries(${savedQueryId})`, {

          
            headers: {
                'Authorization': `bearer ${bearerToken}`,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        });
        // Successful creation response
        res.status(201).json({
            message: 'views created successfully',
           // data: response.data
        });
    } catch (error) {
        console.error('Error  in creating views for an entity :', {
            message: error.message,
            response: error.response ? error.response.data : null,
            config: error.config,  // Log the request configuration for context
            requestData: viewsdata // Log the mapped entity data
        });

        res.status(error.response ? error.response.status : 500).json({
            message: 'Error in creating a views for  entity ',
            error: error.response ? error.response.data : error.message
        });
   }//
});
app.post('/api/UpdateEntitynew', async (req, res) => {
    const url = process.env.DYNAMICS_API;
    const bearerToken = process.env.BEARER_TOKEN;

    // Entity data from request body
   // const entityData = req.body;
    const entityData = new UpdateEntityMetdata(req.body);

    console.log(JSON.stringify(entityData, null, 2))

    try {
        const response = await axios.put(`${url}EntityDefinitions(${req.body.id})`, entityData, {
          
            headers: {
                'Authorization': `Bearer ${bearerToken}`,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        });
        // Successful creation response
        res.status(201).json({
            message: 'Entity updated successfully',
           // data: response.data
        });
    } catch (error) {
        console.error('Error  in updating  entity:', {
            message: error.message,
            response: error.response ? error.response.data : null,
            config: error.config,  // Log the request configuration for context
            requestData: entityData // Log the mapped entity data
        });

        res.status(error.response ? error.response.status : 500).json({
            message: 'Error in updating entity ',
            error: error.response ? error.response.data : error.message
        });
    }
});

app.get('/api/entityMetadata', async (req, res) => {
    // Call to fetch the token before fetching metadata
    try {
        const { TENANT_ID, CLIENT_ID, CLIENT_SECRET, YOUR_RESOURCE } = process.env;

        const params = new URLSearchParams();
        params.append('grant_type', 'client_credentials');
        params.append('client_id', CLIENT_ID);
        params.append('client_secret', CLIENT_SECRET);
        params.append('resource', YOUR_RESOURCE);

        const tokenResponse = await axios.post(`https://login.microsoftonline.com/${TENANT_ID}/oauth2/token`, params);
        const tokenData = tokenResponse.data.access_token;
        console.log('Using token:', tokenData);


        const metadata = await fetchEntityMetadata(tokenData);
        res.json(metadata);
    } catch (error) {
        console.error('Error retrieving entity metadata:', error.message);
        console.error('Error fetching entity metadata:', error.response ? error.response.data : error.message);
       console.error('Error details:', error);
  
        res.status(500).send('Error retrieving entity metadata');
    }
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
