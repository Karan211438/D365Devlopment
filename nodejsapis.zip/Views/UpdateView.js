class UpdateView {
    constructor(views) {
        
      this.name = views.NameOftheview;
      this.fetchxml=views.fetchxml
      this.layoutxml = views.layoutxml;
      this.description= views.description;
      this.isdefault=views.isdefault;
      

    }
   
    
   
}

module.exports =  UpdateView 