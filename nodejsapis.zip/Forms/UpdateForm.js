class UpdateForm {
    constructor(forms) {
        
      this.name = forms.Nameoftheform;
      this.formxml=forms.Formxml;
    }
    
}

module.exports =  UpdateForm 
 