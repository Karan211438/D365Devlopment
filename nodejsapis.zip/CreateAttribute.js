class createAttribute {
    constructor(Attribute) {
        // this["@odata.type"] = "Microsoft.Dynamics.CRM.EntityMetadata";
        // this.SchemaName = Attribute.SchemaName;
        // this.DisplayName = this.createLabel(Attribute.DisplayName);
        // this.DisplayCollectionName = tC
        // this.Description = this.createLabel(Attribute.Description);
        // this.OwnershipType = Attribute.OwnershipType; 
        // this.IsActivity = Attribute.IsActivity; 
        // this.HasNotes = Attribute.HasNotes;
        // this.HasActivities = Attribute.HasActivities; 
        this.AttributeType = Attribute.DataType//
        this.AttributeTypeName =  this.craeteAttributeType(Attribute.DataType);
        this.Description = this.createLabel(Attribute.Description);
        this.DisplayName = this.createLabel(Attribute.DisplayName);
        this.SchemaName =  Attribute.SchemaName;
        this["@odata.type"] = "Microsoft.Dynamics.CRM."+ Attribute.DataType.toUpperCase()+ "AttributeMetadata";
        if (Attribute.DataType.toUpperCase() === "STRING") {
            this.FormatName = this.Check(Attribute); // Assuming Check handles max length internally
            this.MaxLength = Attribute.MaxLength; // Ensure Attribute.MaxLength exists
        }
    }
    craeteAttributeType(DataType){
        return{
             "Value": DataType.toUpperCase()+"Type"  
            
        };
    }
    createLabel(label) {
        return {
            "@odata.type": "Microsoft.Dynamics.CRM.Label",
            "LocalizedLabels": [
                {
                    "@odata.type": "Microsoft.Dynamics.CRM.LocalizedLabel",
                    "Label": label,
                    "LanguageCode": 1033 
                }
            ]
        };
    }
    requriedLevel(){
        return{
            "Value": "None",  
             "CanBeChanged": true,  
            "ManagedPropertyLogicalName": "canmodifyrequirementlevelsettings"

        };
    }

    Check(Attribute) {
        switch (Attribute) {
            case "STRING":
                return {
                     
                    Value: "Text"  ,
                };
    
            case "MONEY":
                return {
                    PrecisionSource: 2 
                };
    
            default:
                return null; 
        }
    }
    
    
   
}

module.exports =  createAttribute 
    